package com.example.mohit2906.women_security;

import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Main2Activity extends AppCompatActivity {

    Button BtnNumber,BtnChoose;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        BtnNumber= (Button) findViewById(R.id.BtnNumber);
        BtnChoose= (Button) findViewById(R.id.BtnChoose);

        final FragmentManager fm=getSupportFragmentManager();
        BtnNumber.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                FragmentTransaction ft= fm.beginTransaction();
                ft.replace(R.id.FrmLyt,new FragNumber());
                ft.commit();
            }
        });

        BtnChoose.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                FragmentTransaction ft= fm.beginTransaction();
                ft.replace(R.id.FrmLyt,new FragChooseNumber());
                ft.commit();
            }
        });
    }
}
